<template>
	<view>
		<dynamic-list v-if="PageCur=='dynamic'" :parameter='{}'></dynamic-list>
		<good-friend-list v-if="PageCur=='discover'"></good-friend-list>
		<message v-if="PageCur=='message'"></message>
		<me v-if="PageCur=='me'"></me>
		<view class="cu-bar tabbar bg-white shadow foot">
			<view class="action" :class="PageCur=='dynamic'?'new-text-blue':'new-text-black'" @click="NavChange" data-cur="dynamic" >
				<view :class="PageCur=='dynamic'?'cuIcon-homefill':'cuIcon-home'"></view>
				<view >交友大厅</view>
			</view>
			<view class="action " :class="PageCur=='discover'?'new-text-blue':'new-text-black'" @click="NavChange" data-cur="discover" >
				<view :class="PageCur=='discover'?'cuIcon-discoverfill':'cuIcon-discover'"></view> 
				<view>列表</view>
			</view>
			<view class="action" :class="PageCur=='message'?'new-text-blue':'new-text-black'" @click="NavChange" data-cur="message" >
				<view :class="PageCur=='message'?'cuIcon-messagefill':'cuIcon-message'">
					<view class="cu-tag badge">99</view>
				</view>
				商城 
			</view>
			
			<view class="action" :class="PageCur=='me'?'new-text-blue':'new-text-black'" @click="NavChange" data-cur="me" >
				<view :class="PageCur=='me'?'cuIcon-myfill':'cuIcon-my'">
					<view class="cu-tag badge"></view>
				</view>
				<view >分类</view>
			</view>
			
		</view>
		
		<view class="cu-modal" :class="modalName=='RadioModal'?'show':''" @tap="hideModal">
			<view class="cu-dialog" @tap.stop="">
				<radio-group class="block" @change="RadioChange">
					<view class="cu-list menu text-left">
						<view class="cu-item" v-for="(item,index) in 5" :key="index">
							<label class="flex justify-between align-center flex-sub">
								<view class="flex-sub">Item {{index +1}}</view>
								<radio class="round" :class="radio=='radio' + index?'checked':''" :checked="radio=='radio' + index?true:false"
								 :value="'radio' + index"></radio>
							</label>
						</view>
					</view>
				</radio-group>
			</view>
		</view>
		
	</view>
</template>

<script>
	import dynamicList from '../../component/friendship/dynamic-list.vue'
	import goodFriendList from '../message/good-friend-list.vue'
	export default {
		components: {dynamicList,goodFriendList},
		data() {
			return {
				PageCur: 'dynamic',
				modalName: null,
				radio: 'radio1',
			}
		},
		methods: {
			NavChange: function(e) {
				this.PageCur = e.currentTarget.dataset.cur
			},
			showModal(e) {
				this.modalName = e.currentTarget.dataset.target
			},
			hideModal(e) {
				this.modalName = null
			},
			RadioChange(e) {
				this.radio = e.detail.value
			},
		},
		
	}
</script>

<style>

</style>
