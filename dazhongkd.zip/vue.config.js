module.exports = {
    devServer: {
      open: true,
      port: 9394
    //   proxy: {
    //     '/mall': {
    //       target: 'http://m1.lvyan.vip/api/',
    //       changOrigin: true,
    //       ws: true,
    //       pathRewrite: {
    //         '^/mall': ''
    //       }
    //     }
    //   },
    }
  }